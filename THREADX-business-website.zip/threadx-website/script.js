// THREADX website settings
// IMPORTANT: Replace the sample WhatsApp number and social links below before publishing.
const THREADX_WHATSAPP_NUMBER = "8801XXXXXXXXX"; // Bangladesh format: 8801XXXXXXXXX (no + sign)
const THREADX_INSTAGRAM_URL = "https://www.instagram.com/";
const THREADX_FACEBOOK_URL = "https://www.facebook.com/";

function whatsappLink(message) {
  return `https://wa.me/${THREADX_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

document.getElementById("contactWhatsApp").href = whatsappLink("Hi THREADX! I'd like to know more about your collection.");
document.getElementById("floatingWhatsApp").href = whatsappLink("Hi THREADX! I'd like to place an order.");
document.getElementById("instagramLink").href = THREADX_INSTAGRAM_URL;
document.getElementById("facebookLink").href = THREADX_FACEBOOK_URL;
document.getElementById("year").textContent = new Date().getFullYear();

document.querySelectorAll(".quick-order").forEach(button => {
  button.addEventListener("click", () => {
    const product = button.dataset.product;
    window.open(whatsappLink(`Hi THREADX! I want to order: ${product}. Please share available sizes and delivery details.`), "_blank", "noopener");
  });
});

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const category = button.dataset.filter;
    document.querySelectorAll(".product-card").forEach(card => {
      card.hidden = category !== "all" && card.dataset.category !== category;
    });
  });
});

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));
