# THREADX Clothing Store Website

A responsive, modern black-and-white clothing store website built with plain HTML, CSS and JavaScript. It is suitable for free hosting on GitHub Pages.

## Files
- `index.html` — website content and product listings
- `style.css` — responsive layout and visual styling
- `script.js` — product filters, mobile menu and WhatsApp ordering

## Before publishing
1. Open `script.js`.
2. Replace `8801XXXXXXXXX` with your WhatsApp number in international format, without `+` or spaces. Example format: `88017XXXXXXXX`.
3. Replace the Instagram and Facebook URLs with your actual business profile links.
4. Edit the sample product names, prices, categories and image URLs in `index.html`.
5. Update the page title and brand description if needed.

The current product details and images are placeholders for demonstration. Check that you have permission to use any product images you publish.

## Publish free with GitHub Pages
1. Sign in at https://github.com/.
2. Create a **Public** repository named `threadx-website`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to publish. Your site URL will look like:
   `https://YOUR-USERNAME.github.io/threadx-website/`

## Important
GitHub Pages provides static website hosting. This version sends orders to WhatsApp; it does not process card payments, maintain inventory, or store customer orders in a database.
