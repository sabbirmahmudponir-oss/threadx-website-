// THREADX website settings
// Replace the example number with your WhatsApp number, including country code.
// Bangladesh example format: 8801XXXXXXXXX (no +, spaces or dashes).
const WHATSAPP_NUMBER = "8801XXXXXXXXX";

function whatsappLink(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

document.querySelectorAll("[data-product]").forEach((link) => {
  const product = link.dataset.product;
  link.href = whatsappLink(`Hi THREADX! I would like to order or ask about: ${product}. Please share the price, sizes and availability.`);
  link.target = "_blank";
  link.rel = "noopener";
});

const contactLink = document.getElementById("contactWhatsApp");
contactLink.href = whatsappLink("Hi THREADX! I would like to know more about your collection.");
contactLink.target = "_blank";
contactLink.rel = "noopener";

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});
mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});
document.getElementById("year").textContent = new Date().getFullYear();
