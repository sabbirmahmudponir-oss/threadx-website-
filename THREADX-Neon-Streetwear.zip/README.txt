THREADX — NEON STREETWEAR WEBSITE
=================================

FILES
- index.html   Main website structure and content
- style.css    Neon colors, layout, responsive styling
- script.js    Mobile menu and WhatsApp ordering links

BEFORE PUBLISHING
1. Open script.js in Notepad or VS Code.
2. Find: const WHATSAPP_NUMBER = "8801XXXXXXXXX";
3. Replace it with your WhatsApp number in international format.
   Bangladesh example: 8801XXXXXXXXX
   Do not include +, spaces or dashes.
4. In index.html, replace sample product names, sample descriptions and
   "৳ PRICE" with your real products and prices.
5. Replace the CSS-made sample shirt graphics with your own product photos
   if you have them.

PUBLISH ON GITHUB PAGES
1. Sign in at https://github.com/
2. Click the + icon, then New repository.
3. Name it: threadx-store
4. Choose Public, then click Create repository.
5. Click Add file > Upload files.
6. Upload index.html, style.css, script.js and README.txt
   (upload the files, not the containing folder).
7. Click Commit changes.
8. Open the repository's Settings tab.
9. Choose Pages from the left menu.
10. Under Build and deployment, choose Deploy from a branch.
11. Select branch main and folder /(root), then Save.
12. Wait a few minutes. GitHub will show your website URL in the Pages section.

IMPORTANT
- Keep index.html in the repository root.
- GitHub Pages hosts static websites. This package does not need a paid server.
- WhatsApp orders open a chat; customers and you arrange payment and delivery
  directly. There is no built-in cart, online payment gateway or inventory system.
